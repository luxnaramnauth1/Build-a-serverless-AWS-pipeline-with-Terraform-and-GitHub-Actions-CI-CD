# One-time bootstrap (run locally with admin credentials, local state):
#   cd terraform/bootstrap && terraform init && terraform apply -var="github_repo=YOUR_USER/YOUR_REPO"
# Creates: remote-state bucket, GitHub OIDC provider, and the IAM role GitHub Actions assumes.
terraform {
  required_version = ">= 1.10.0"
  required_providers {
    aws = { source = "hashicorp/aws", version = "~> 5.0" }
  }
}

variable "aws_region" {
  type    = string
  default = "eu-west-1"
}

variable "github_repo" {
  description = "owner/repo allowed to deploy, e.g. luxna/aws-sales-data-pipeline"
  type        = string
}

variable "project" {
  type    = string
  default = "sales-pipeline"
}

provider "aws" {
  region = var.aws_region
}

data "aws_caller_identity" "current" {}

resource "aws_s3_bucket" "state" {
  bucket = "${var.project}-tfstate-${data.aws_caller_identity.current.account_id}"
}

resource "aws_s3_bucket_versioning" "state" {
  bucket = aws_s3_bucket.state.id
  versioning_configuration {
    status = "Enabled"
  }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "state" {
  bucket = aws_s3_bucket.state.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm = "AES256"
    }
  }
}

resource "aws_s3_bucket_public_access_block" "state" {
  bucket                  = aws_s3_bucket.state.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_iam_openid_connect_provider" "github" {
  url             = "https://token.actions.githubusercontent.com"
  client_id_list  = ["sts.amazonaws.com"]
  thumbprint_list = ["6938fd4d98bab03faadb97b34396831e3780aea1"]
}

data "aws_iam_policy_document" "trust" {
  statement {
    actions = ["sts:AssumeRoleWithWebIdentity"]
    principals {
      type        = "Federated"
      identifiers = [aws_iam_openid_connect_provider.github.arn]
    }
    condition {
      test     = "StringEquals"
      variable = "token.actions.githubusercontent.com:aud"
      values   = ["sts.amazonaws.com"]
    }
    condition {
      test     = "StringLike"
      variable = "token.actions.githubusercontent.com:sub"
      values   = ["repo:${var.github_repo}:*"]
    }
  }
}

resource "aws_iam_role" "github_deploy" {
  name               = "${var.project}-github-deploy"
  assume_role_policy = data.aws_iam_policy_document.trust.json
}

# Scoped to the services this stack uses and to resources named after the project.
# Tighten further for production (e.g. permission boundary, specific ARNs).
data "aws_iam_policy_document" "deploy" {
  statement {
    sid       = "ProjectBuckets"
    actions   = ["s3:*"]
    resources = ["arn:aws:s3:::${var.project}-*", "arn:aws:s3:::${var.project}-*/*"]
  }
  statement {
    sid       = "ProjectLambdaAndLogs"
    actions   = ["lambda:*", "logs:*"]
    resources = ["arn:aws:lambda:*:*:function:${var.project}-*", "arn:aws:logs:*:*:log-group:/aws/lambda/${var.project}-*", "arn:aws:logs:*:*:log-group:/aws/lambda/${var.project}-*:*"]
  }
  statement {
    sid       = "LogsDescribe"
    actions   = ["logs:DescribeLogGroups", "logs:ListTagsForResource", "logs:ListTagsLogGroup"]
    resources = ["*"]
  }
  statement {
    sid       = "ProjectRoles"
    actions   = ["iam:*Role*", "iam:*RolePolicy*", "iam:TagRole", "iam:UntagRole"]
    resources = ["arn:aws:iam::*:role/${var.project}-*"]
  }
  statement {
    sid       = "GlueAthenaSnsAlarms"
    actions   = ["glue:*", "athena:*", "sns:*", "cloudwatch:*"]
    resources = ["*"]
  }
  statement {
    sid       = "ProtectDeployRole"
    effect    = "Deny"
    actions   = ["iam:*"]
    resources = [aws_iam_role.github_deploy.arn]
  }
  statement {
    sid       = "Identity"
    actions   = ["sts:GetCallerIdentity"]
    resources = ["*"]
  }
}

resource "aws_iam_role_policy" "deploy" {
  name   = "terraform-deploy"
  role   = aws_iam_role.github_deploy.id
  policy = data.aws_iam_policy_document.deploy.json
}

output "state_bucket" { value = aws_s3_bucket.state.bucket }
output "github_role_arn" { value = aws_iam_role.github_deploy.arn }
