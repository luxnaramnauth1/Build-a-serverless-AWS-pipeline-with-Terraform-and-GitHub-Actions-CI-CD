variable "aws_region" {
  type    = string
  default = "eu-west-1"
}

variable "project" {
  type    = string
  default = "sales-pipeline"
}

variable "environment" {
  type    = string
  default = "dev"
}

variable "alert_email" {
  description = "Email for failure alarms (leave empty to skip the subscription)."
  type        = string
  default     = ""
}

variable "log_retention_days" {
  type    = number
  default = 14
}

variable "lambda_memory_mb" {
  type    = number
  default = 512
}

variable "force_destroy" {
  description = "Allow terraform destroy to delete non-empty buckets (convenient for a demo; set false in production)."
  type        = bool
  default     = true
}
