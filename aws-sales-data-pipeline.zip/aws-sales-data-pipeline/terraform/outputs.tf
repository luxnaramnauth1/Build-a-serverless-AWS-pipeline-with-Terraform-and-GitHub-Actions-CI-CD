output "raw_bucket" { value = aws_s3_bucket.this["raw"].bucket }
output "curated_bucket" { value = aws_s3_bucket.this["curated"].bucket }
output "lambda_name" { value = aws_lambda_function.transform.function_name }
output "athena_workgroup" { value = aws_athena_workgroup.this.name }
output "glue_database" { value = aws_glue_catalog_database.this.name }
