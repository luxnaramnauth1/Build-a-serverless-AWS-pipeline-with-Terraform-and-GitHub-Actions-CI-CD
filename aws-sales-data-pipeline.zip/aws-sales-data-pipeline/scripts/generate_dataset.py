"""Generate a synthetic e-commerce sales dataset (with deliberate data-quality problems).

Usage:  python scripts/generate_dataset.py [--rows 5000] [--out data/sales_orders.csv]
Deterministic (seeded), so everyone gets the same file.
"""
import argparse
import csv
import random
from datetime import date, timedelta

CATALOG = {
    "Electronics": [("Wireless Mouse", 24.99), ("USB-C Hub", 39.5), ("Bluetooth Speaker", 59.0), ("Webcam HD", 49.9)],
    "Home": [("Desk Lamp", 29.95), ("Coffee Maker", 79.0), ("Air Purifier", 129.0), ("Throw Blanket", 34.5)],
    "Sports": [("Yoga Mat", 22.0), ("Dumbbell Set", 89.0), ("Running Belt", 15.75), ("Water Bottle", 18.4)],
    "Books": [("Data Engineering Handbook", 44.0), ("Cloud Patterns", 39.99), ("SQL Cookbook", 32.5)],
    "Fashion": [("Rain Jacket", 74.0), ("Canvas Sneakers", 54.95), ("Wool Socks", 12.0)],
}
COUNTRIES = ["US", "UK", "DE", "FR", "IN", "AU", "CA", "MU"]
PAYMENTS = ["credit_card", "paypal", "debit_card", "bank_transfer"]
FIELDS = ["order_id", "order_date", "customer_id", "product", "category",
          "quantity", "unit_price", "country", "payment_method"]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=5000)
    ap.add_argument("--out", default="data/sales_orders.csv")
    args = ap.parse_args()

    rnd = random.Random(42)
    start, span = date(2023, 1, 1), 730
    rows = []
    for i in range(1, args.rows - 160 + 1):
        cat = rnd.choice(list(CATALOG))
        product, price = rnd.choice(CATALOG[cat])
        rows.append({
            "order_id": f"ORD-{i:06d}",
            "order_date": (start + timedelta(days=rnd.randrange(span))).isoformat(),
            "customer_id": f"CUST-{rnd.randint(1, 900):04d}",
            "product": product, "category": cat,
            "quantity": rnd.randint(1, 5),
            "unit_price": f"{price:.2f}",
            "country": rnd.choice(COUNTRIES),
            "payment_method": rnd.choice(PAYMENTS),
        })
    good = list(rows)
    # ---- inject 160 bad rows (3.2%) so the quarantine path has something to do
    def bad(**kw):
        r = dict(rnd.choice(good))
        r["order_id"] = f"ORD-B{rnd.randint(1, 10**6):06d}"
        r.update(kw)
        return r
    for _ in range(40):  # negative quantity
        rows.append(bad(quantity=-rnd.randint(1, 3)))
    for _ in range(30):  # missing customer
        rows.append(bad(customer_id=""))
    for _ in range(30):  # impossible date
        rows.append(bad(order_date="31/02/2024"))
    for _ in range(40):  # exact duplicates of good rows
        rows.append(dict(rnd.choice(good)))
    for _ in range(20):  # non-numeric price
        rows.append(bad(unit_price="N/A"))
    rnd.shuffle(rows)

    with open(args.out, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    print(f"Wrote {len(rows)} rows to {args.out}")


if __name__ == "__main__":
    main()
