"""Post-deploy smoke test: upload the sample file, wait for curated output, run an Athena query.

    python scripts/smoke_test.py --raw-bucket X --curated-bucket Y --workgroup W --database D
"""
import argparse
import sys
import time

import boto3


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw-bucket", required=True)
    ap.add_argument("--curated-bucket", required=True)
    ap.add_argument("--workgroup", required=True)
    ap.add_argument("--database", required=True)
    ap.add_argument("--file", default="data/sales_orders.csv")
    a = ap.parse_args()

    s3 = boto3.client("s3")
    key = f"incoming/smoke_{int(time.time())}.csv"
    s3.upload_file(a.file, a.raw_bucket, key)
    print("Uploaded", key)

    stem = key.split("/")[-1].rsplit(".", 1)[0]
    for _ in range(30):
        resp = s3.list_objects_v2(Bucket=a.curated_bucket, Prefix="quarantine/")
        if any(stem in o["Key"] for o in resp.get("Contents", [])):
            print("Curated output detected")
            break
        time.sleep(5)
    else:
        print("FAIL: no output after 150s")
        return 1

    ath = boto3.client("athena")
    q = ath.start_query_execution(
        QueryString="SELECT category, round(sum(total_amount),2) AS revenue FROM orders GROUP BY 1 ORDER BY 2 DESC",
        QueryExecutionContext={"Database": a.database}, WorkGroup=a.workgroup)["QueryExecutionId"]
    while True:
        st = ath.get_query_execution(QueryExecutionId=q)["QueryExecution"]["Status"]["State"]
        if st in ("SUCCEEDED", "FAILED", "CANCELLED"):
            break
        time.sleep(2)
    if st != "SUCCEEDED":
        print("FAIL: Athena query", st)
        return 1
    for r in ath.get_query_results(QueryExecutionId=q)["ResultSet"]["Rows"]:
        print([c.get("VarCharValue") for c in r["Data"]])
    print("Smoke test passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
