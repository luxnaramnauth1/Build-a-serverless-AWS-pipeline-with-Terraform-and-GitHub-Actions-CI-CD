"""Run the transform on your machine - no AWS needed.

    python scripts/run_local.py                      # uses data/sales_orders.csv
    python scripts/run_local.py path/to/file.csv
Writes results to ./local_output/ and prints a small revenue report.
"""
import csv
import gzip
import io
import os
import sys
from collections import defaultdict

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "transform"))
import handler  # noqa: E402


def main() -> None:
    path = sys.argv[1] if len(sys.argv) > 1 else "data/sales_orders.csv"
    with open(path, encoding="utf-8-sig") as f:
        out = handler.process_csv_text(f.read(), path)

    for k, data in {**out["curated"], **out["rejects"]}.items():
        dest = os.path.join("local_output", k)
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "wb") as f:
            f.write(data)

    s = out["stats"]
    print(f"\nRows in: {s['rows_in']}   good: {s['rows_good']}   rejected: {s['rows_rejected']}   partitions: {s['partitions']}")
    print("Reject reasons:", s["reject_reasons"])

    by_cat, by_month = defaultdict(float), defaultdict(float)
    for k, data in out["curated"].items():
        for r in csv.DictReader(io.StringIO(gzip.decompress(data).decode())):
            by_cat[r["category"]] += float(r["total_amount"])
            by_month[r["order_date"][:7]] += float(r["total_amount"])
    print("\nRevenue by category")
    for c, v in sorted(by_cat.items(), key=lambda x: -x[1]):
        print(f"  {c:<12} {v:>12,.2f}")
    top = sorted(by_month.items(), key=lambda x: -x[1])[:3]
    print("\nTop 3 months:", ", ".join(f"{m} ({v:,.0f})" for m, v in top))
    print("\nFiles written under ./local_output/")


if __name__ == "__main__":
    main()
