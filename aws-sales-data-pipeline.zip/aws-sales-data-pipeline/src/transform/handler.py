"""Lambda: validate + clean a raw sales CSV, write partitioned gzip CSV to the curated bucket.

Flow:  S3 (raw/incoming/*.csv)  ->  this Lambda  ->  S3 curated
         good rows  -> orders/year=YYYY/month=MM/<file>.csv.gz   (queried by Athena)
         bad rows   -> quarantine/<file>_rejects.csv             (with a reason column)
Output keys are derived from the input file name, so re-processing a file is idempotent.
"""
import csv
import gzip
import io
import json
import logging
import os
from collections import defaultdict
from datetime import datetime
from urllib.parse import unquote_plus

logger = logging.getLogger()
logger.setLevel(logging.INFO)

REQUIRED = ["order_id", "order_date", "customer_id", "product", "category",
            "quantity", "unit_price", "country", "payment_method"]
OUT_FIELDS = ["order_id", "customer_id", "product", "category", "quantity",
              "unit_price", "total_amount", "country", "payment_method", "order_date"]

_s3 = None


def get_s3():
    """Lazy boto3 client (keeps unit tests free of AWS)."""
    global _s3
    if _s3 is None:
        import boto3
        _s3 = boto3.client("s3")
    return _s3


# ----------------------------------------------------------------- pure logic
def validate_row(row: dict):
    """Return (clean_row, None) or (None, reason)."""
    r = {k: (row.get(k) or "").strip() for k in REQUIRED}
    for field in ("order_id", "customer_id", "product", "category", "country", "payment_method"):
        if not r[field]:
            return None, f"missing_{field}"
    try:
        d = datetime.strptime(r["order_date"], "%Y-%m-%d")
    except ValueError:
        return None, "invalid_order_date"
    try:
        qty = int(r["quantity"])
    except ValueError:
        return None, "invalid_quantity"
    if qty <= 0:
        return None, "non_positive_quantity"
    try:
        price = float(r["unit_price"])
    except ValueError:
        return None, "invalid_unit_price"
    if price <= 0:
        return None, "non_positive_unit_price"
    return {
        "order_id": r["order_id"], "customer_id": r["customer_id"], "product": r["product"],
        "category": r["category"].title(), "quantity": qty, "unit_price": f"{price:.2f}",
        "total_amount": f"{qty * price:.2f}", "country": r["country"].upper(),
        "payment_method": r["payment_method"].lower(), "order_date": d.strftime("%Y-%m-%d"),
    }, None


def process_csv_text(text: str, source_name: str) -> dict:
    """Validate, dedupe and partition. Returns {'curated': {key: bytes}, 'rejects': {key: bytes}, 'stats': {...}}."""
    reader = csv.DictReader(io.StringIO(text))
    missing = [c for c in REQUIRED if c not in (reader.fieldnames or [])]
    if missing:
        raise ValueError(f"Input file is missing columns: {missing}")

    stem = os.path.splitext(os.path.basename(source_name))[0]
    seen, good, rejects, total = set(), [], [], 0
    for row in reader:
        total += 1
        clean, reason = validate_row(row)
        if reason is None and clean["order_id"] in seen:
            clean, reason = None, "duplicate_order_id"
        if reason:
            rejects.append({**{k: row.get(k, "") for k in REQUIRED}, "reject_reason": reason})
            continue
        seen.add(clean["order_id"])
        good.append(clean)

    parts = defaultdict(list)
    for r in good:
        y, m, _ = r["order_date"].split("-")
        parts[(y, m)].append(r)

    curated = {}
    for (y, m), rows in sorted(parts.items()):
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=OUT_FIELDS, lineterminator="\n")
        w.writeheader()  # Glue table skips 1 header line
        w.writerows(rows)
        curated[f"orders/year={y}/month={m}/{stem}.csv.gz"] = gzip.compress(buf.getvalue().encode())

    reject_files = {}
    if rejects:
        buf = io.StringIO()
        w = csv.DictWriter(buf, fieldnames=REQUIRED + ["reject_reason"], lineterminator="\n")
        w.writeheader()
        w.writerows(rejects)
        reject_files[f"quarantine/{stem}_rejects.csv"] = buf.getvalue().encode()

    reasons = defaultdict(int)
    for r in rejects:
        reasons[r["reject_reason"]] += 1
    stats = {"source": source_name, "rows_in": total, "rows_good": len(good),
             "rows_rejected": len(rejects), "partitions": len(curated), "reject_reasons": dict(reasons)}
    return {"curated": curated, "rejects": reject_files, "stats": stats}


# ------------------------------------------------------------------- Lambda
def lambda_handler(event, context=None):
    curated_bucket = os.environ["CURATED_BUCKET"]
    s3 = get_s3()
    results = []
    for rec in event.get("Records", []):
        bucket = rec["s3"]["bucket"]["name"]
        key = unquote_plus(rec["s3"]["object"]["key"])
        logger.info("Processing s3://%s/%s", bucket, key)
        body = s3.get_object(Bucket=bucket, Key=key)["Body"].read().decode("utf-8-sig")
        out = process_csv_text(body, key)
        for k, data in {**out["curated"], **out["rejects"]}.items():
            s3.put_object(Bucket=curated_bucket, Key=k, Body=data, ServerSideEncryption="AES256")
        logger.info(json.dumps(out["stats"]))
        results.append(out["stats"])
    return {"processed": results}
