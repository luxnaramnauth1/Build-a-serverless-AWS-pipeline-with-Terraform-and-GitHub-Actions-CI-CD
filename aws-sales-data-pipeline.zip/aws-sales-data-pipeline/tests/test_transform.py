import csv
import gzip
import io
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src", "transform"))
import handler  # noqa: E402

HEADER = "order_id,order_date,customer_id,product,category,quantity,unit_price,country,payment_method\n"
GOOD = "ORD-1,2024-03-05,CUST-1,Mouse,electronics,2,10.50,us,PayPal\n"


def good_row(**kw):
    row = dict(order_id="ORD-1", order_date="2024-03-05", customer_id="C1", product="Mouse",
               category="electronics", quantity="2", unit_price="10.50", country="us", payment_method="PayPal")
    row.update(kw)
    return row


def test_valid_row_is_normalised():
    clean, reason = handler.validate_row(good_row())
    assert reason is None
    assert clean["total_amount"] == "21.00"
    assert clean["category"] == "Electronics"
    assert clean["country"] == "US"
    assert clean["payment_method"] == "paypal"


@pytest.mark.parametrize("override,expected", [
    ({"quantity": "-1"}, "non_positive_quantity"),
    ({"quantity": "abc"}, "invalid_quantity"),
    ({"customer_id": ""}, "missing_customer_id"),
    ({"order_date": "31/02/2024"}, "invalid_order_date"),
    ({"unit_price": "N/A"}, "invalid_unit_price"),
    ({"unit_price": "0"}, "non_positive_unit_price"),
])
def test_bad_rows_rejected(override, expected):
    clean, reason = handler.validate_row(good_row(**override))
    assert clean is None and reason == expected


def test_duplicates_and_partitioning():
    text = (HEADER + GOOD + GOOD +
            "ORD-2,2024-04-01,CUST-2,Lamp,home,1,30.00,uk,debit_card\n"
            "ORD-3,2023-12-31,CUST-3,Book,books,1,9.99,de,paypal\n")
    out = handler.process_csv_text(text, "incoming/batch1.csv")
    assert out["stats"]["rows_in"] == 4
    assert out["stats"]["rows_good"] == 3
    assert out["stats"]["reject_reasons"] == {"duplicate_order_id": 1}
    assert set(out["curated"]) == {
        "orders/year=2024/month=03/batch1.csv.gz",
        "orders/year=2024/month=04/batch1.csv.gz",
        "orders/year=2023/month=12/batch1.csv.gz",
    }
    assert "quarantine/batch1_rejects.csv" in out["rejects"]


def test_gzip_roundtrip_has_header_and_total():
    out = handler.process_csv_text(HEADER + GOOD, "x.csv")
    data = next(iter(out["curated"].values()))
    rows = list(csv.DictReader(io.StringIO(gzip.decompress(data).decode())))
    assert rows[0]["total_amount"] == "21.00"


def test_missing_columns_raises():
    with pytest.raises(ValueError):
        handler.process_csv_text("a,b\n1,2\n", "bad.csv")


class FakeS3:
    def __init__(self, objects):
        self.objects, self.put = objects, {}

    def get_object(self, Bucket, Key):
        return {"Body": io.BytesIO(self.objects[(Bucket, Key)])}

    def put_object(self, Bucket, Key, Body, **kw):
        self.put[(Bucket, Key)] = Body


def test_lambda_handler_end_to_end(monkeypatch):
    fake = FakeS3({("raw", "incoming/my file.csv"): (HEADER + GOOD).encode()})
    monkeypatch.setattr(handler, "get_s3", lambda: fake)
    monkeypatch.setenv("CURATED_BUCKET", "curated")
    event = {"Records": [{"s3": {"bucket": {"name": "raw"}, "object": {"key": "incoming/my+file.csv"}}}]}
    res = handler.lambda_handler(event)
    assert res["processed"][0]["rows_good"] == 1
    assert ("curated", "orders/year=2024/month=03/my file.csv.gz") in fake.put


def test_full_sample_dataset():
    path = os.path.join(os.path.dirname(__file__), "..", "data", "sales_orders.csv")
    if not os.path.exists(path):
        pytest.skip("sample dataset not generated")
    with open(path, encoding="utf-8") as f:
        s = handler.process_csv_text(f.read(), "sales_orders.csv")["stats"]
    assert s["rows_in"] == 5000
    assert s["rows_rejected"] == 160
    assert s["rows_good"] == 4840
